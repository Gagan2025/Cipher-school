import { Component } from "react";
class ToDoscreem extends Component{
    render(){
        return(
       <h1 className="ui heading center">To Do List</h1>
        )
    }
    }
export default ToDoscreem;
